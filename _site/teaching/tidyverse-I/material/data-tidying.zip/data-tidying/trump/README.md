# source

https://projects.fivethirtyeight.com/trump-approval-ratings/

Downloaded 2020-10-04 at 15:41